const host = 'https://api.spacexdata.com';
export const launchesAPI = `${host}/v4/launches`;