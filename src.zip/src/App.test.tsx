import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';
import { Launches } from './pages'
import { mount } from 'enzyme';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/SpaceX 50 Most Recent Launches/i);
  expect(linkElement).toBeInTheDocument();
});


// describe('when things happened', () => {
//   let home: { find: (arg0: string) => { (): any; new(): any; length: any; }; };
//   const api = {};

//   beforeEach(() => {
//       // This will execute your useEffect() hook on your component
//       // NOTE: You should use exactly React.useEffect() in your component,
//       // but not useEffect() with React.useEffect import
//       jest.spyOn(React, 'useEffect').mockImplementation(f => f());
//       // component = shallow(<Component/>);
//   });

//   // Note that here we wrap test function with withTimeout()
//   test('should show a button', (done) => withTimeout(done, () => {
//       expect(home.find('.button').length).toEqual(1);
//   }));
// });

it('should disable submit button on submit click', () => {
  const wrapper = mount(<Launches searchByTerm={function (searchTerm: string): void {
  } } />);
  expect(wrapper.find('.ag-center-cols-container')).toHaveLength(50);
    
  // const submitButton = wrapper.find(Button);
  // submitButton.simulate('click');

  // expect(submitButton.prop('disabled')).toBeTruthy();
});