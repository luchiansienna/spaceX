import React, { useState, useEffect } from 'react';
import TextField from '@mui/material/TextField';

export const Input = (props: { id: string, name: string, searchByTerm: (searchTerm: string) => void }) => {
    const { id, name, searchByTerm } = props;
    const [query, setQuery] = useState("");
    const onTextChange = (e: any) => setQuery(e.target.value);
    useEffect(() => {
        const timeOutId = setTimeout(() => searchByTerm(query), 500);
        return () => clearTimeout(timeOutId);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [query]);

    return <TextField id={id} label={name} variant="outlined" type="search" onChange={onTextChange} />;
};
